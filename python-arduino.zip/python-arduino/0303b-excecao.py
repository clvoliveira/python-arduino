import pyfirmata

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = pyfirmata.Arduino('COM3')
arduino.digital[13].mode = pyfirmata.OUTPUT
estado = True
tempo = 0
try:
    while tempo <= 0:
        try:
            tempo = float(input('Digite o tempo: '))
            if tempo <= 0:
                print ('ERRO! Digite um número real positivo.')
        except:
            print ('ERRO! Digite um número real positivo.')
    while True:
        arduino.digital[13].write(estado)
        arduino.pass_time(tempo)
        estado = not estado
except KeyboardInterrupt:
    arduino.exit()
