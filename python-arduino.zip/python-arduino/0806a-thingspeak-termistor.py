import http.client
from pyfirmata import Arduino, util
from math import log

def obter_temp_celsius (valor):
  tempK = log(10000.0 * (1.0 / valor - 1))
  tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
  tempC = tempK - 273.15
  return tempC

CHAVE = 'especificar_chave'
SERVIDOR = 'api.thingspeak.com'
# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
termistor = arduino.get_pin('a:0:i')
termistor.enable_reporting()

while True:
  valor = str(termistor.read())
  if valor != 'None':
    temp = round(obter_temp_celsius(float(valor)), 1)
    print (temp, '°C')
    url = '/update?api_key=' + CHAVE + '&field1=' + str(temp)
    print(url)
    con = http.client.HTTPSConnection(SERVIDOR)
    con.request('GET', url)
    resp = con.getresponse()
    print(resp.status, resp.reason)
    arduino.pass_time(60.0)
 
