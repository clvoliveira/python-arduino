from pyfirmata import Arduino, util

anterior = False
num = 0

digito = [
    [ 1, 1, 1, 1, 1, 1, 0 ],
    [ 0, 1, 1, 0, 0, 0, 0 ],
    [ 1, 1, 0, 1, 1, 0, 1 ],
    [ 1, 1, 1, 1, 0, 0, 1 ],
    [ 0, 1, 1, 0, 0, 1, 1 ],
    [ 1, 0, 1, 1, 0, 1, 1 ],
    [ 1, 0, 1, 1, 1, 1, 1 ],
    [ 1, 1, 1, 0, 0, 0, 0 ],
    [ 1, 1, 1, 1, 1, 1, 1 ],
    [ 1, 1, 1, 0, 0, 1, 1 ]
]

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()

botao = arduino.get_pin('d:2:i')
seg = list()
seg.append(arduino.get_pin('d:7:o'))
seg.append(arduino.get_pin('d:8:o'))
seg.append(arduino.get_pin('d:9:o'))
seg.append(arduino.get_pin('d:10:o'))
seg.append(arduino.get_pin('d:11:o'))
seg.append(arduino.get_pin('d:12:o'))
seg.append(arduino.get_pin('d:13:o'))

def exibir(numero):
    for i in range(0, 7):
        seg[i].write(digito[numero][i])

exibir (num)
while True:
    valor = botao.read()
    if valor == True and anterior == False:
        num = num + 1
        if num > 9:
            num = 0
        exibir(num)
    anterior = valor
    arduino.pass_time(0.05)
