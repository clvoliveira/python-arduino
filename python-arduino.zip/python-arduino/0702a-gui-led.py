from pyfirmata import Arduino, OUTPUT
from tkinter import *

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'
arduino = Arduino(PORTA)

arduino.digital[13].mode = OUTPUT

def acender():
  arduino.digital[13].write(1)

def apagar():
  arduino.digital[13].write(0)
  
janela = Tk()
janela.title("Acender e apagar LED com botão")
janela.geometry("350x60")

frame = Frame(master=janela)
frame.pack()

botaoacende = Button(master=frame, text="Acender",command=acender)
botaoacende.grid(row=0, column=0)

botaoapaga = Button(master=frame, text="Apagar",command=apagar)
botaoapaga.grid(row=0, column=1)

janela.mainloop()