from pyfirmata import Arduino, util, INPUT
from datetime import datetime
import lcd
from math import log

def obter_temp_celsius (valor):
    tempK = log(10000.0 * (1.0 / valor - 1))
    tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
    tempC = tempK - 273.15
    return tempC

mes_extenso = ['Janeiro', 'Fevereiro', 'Marco', 'Abril',
               'Maio', 'Junho', 'Julho', 'Agosto',
               'Setembro', 'Outubro', 'Novembro', 'Dezembro']
dia_semana = ['Segunda', 'Terca', 'Quarta', 'Quinta',
              'Sexta', 'Sabado', 'Domingo']
anterior = False
funcao  =  0
linha = ['', '']

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
botao = arduino.get_pin('d:6:i')
termistor = arduino.get_pin('a:0:i')
termistor.enable_reporting()
it = util.Iterator(arduino)
it.start()

while True:
    temperatura = str(termistor.read())
    if temperatura != 'None':
        temperatura = float(temperatura)
        temperatura = round(obter_temp_celsius(temperatura), 1)

    agora = datetime.now()
    valor = botao.read()
    
    if valor == True and anterior == False:
        lcd.limpar(arduino)
        funcao = funcao + 1
        if funcao > 1:
            funcao = 0

    if funcao == 0:
        linha[0] = str(agora.day) + '/' + str(agora.month) + '/' + str(agora.year)
        linha[1] = str(agora.hour) + ':' + str(agora.minute).zfill(2) + ':' + str(agora.second).zfill(2)
    else:
        linha[0] = mes_extenso[agora.month - 1] + ' ' + str(agora.day)
        linha[1] = dia_semana[agora.weekday()]
    
    for i in range(2):
        lcd.escrever(arduino, 0, i, linha[i])
    lcd.escrever(arduino, 10, 1, str(temperatura) + "'C")
        
    anterior = valor
    arduino.pass_time(0.5)
