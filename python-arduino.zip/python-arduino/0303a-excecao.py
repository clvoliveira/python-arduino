import pyfirmata

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = pyfirmata.Arduino('COM3')

arduino.digital[13].mode = pyfirmata.OUTPUT

try:
    while True:
        arduino.digital[13].write(1)
        arduino.pass_time(0.5)
        arduino.digital[13].write(0)
        arduino.pass_time(0.5)
except KeyboardInterrupt:
    arduino.exit()

