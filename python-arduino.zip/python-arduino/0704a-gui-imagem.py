from pyfirmata import Arduino, util, OUTPUT, INPUT
from tkinter import *
from PIL import Image, ImageTk

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
arduino.digital[13].mode = OUTPUT
arduino.digital[2].mode = INPUT
it = util.Iterator(arduino)
it.start()

janela = Tk()
janela.title("Alterando a imagem com push button")
janela.geometry("500x300")

frame = Frame(master=janela)
frame.pack()

def troca_imagem():
  valor = arduino.digital[2].read()
  arduino.digital[13].write(valor)
  if valor == True:
    ler = Image.open("led-on.png")
    render = ImageTk.PhotoImage(ler)
    img = Label(janela, image=render)
    img.image = render
    img.place(x=100,y=0)
  else:
    ler = Image.open("led-off.png")
    render = ImageTk.PhotoImage(ler)
    img = Label(janela, image=render)
    img.image = render
    img.place(x=100,y=0)
  janela.after(100,troca_imagem)

janela.protocol('WM_DELETE_WINDOW', janela.destroy)
janela.after(100,troca_imagem)
janela.mainloop()