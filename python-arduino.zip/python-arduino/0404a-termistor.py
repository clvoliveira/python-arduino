from pyfirmata import Arduino, util
from math import log

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
arduino.analog[0].enable_reporting()
while True:
    valor = str(arduino.analog[0].read())
    print (valor)
    if valor != 'None':
        valor = float(valor)
        tempK = log(10000.0 * (1.0 / valor - 1))
        tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
        tempC = tempK - 273.15
        print (tempC)
        arduino.pass_time(5.0)

