from pyfirmata import Arduino, PWM

import random

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
vermelho = 9
azul = 6
verde = 5

arduino.digital[vermelho].mode = PWM
arduino.digital[azul].mode = PWM
arduino.digital[verde].mode = PWM

while True:
    arduino.digital[vermelho].write(random.random())
    arduino.digital[azul].write(random.random())
    arduino.digital[verde].write(random.random())
    arduino.pass_time(2.0)

