x = 2
while x <= 10:
  print (x)
  x = x + 2