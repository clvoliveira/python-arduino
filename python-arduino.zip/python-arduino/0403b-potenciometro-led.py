from pyfirmata import Arduino, OUTPUT, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
pot = arduino.get_pin('a:0:i')
led = arduino.get_pin('d:9:o')
pot.enable_reporting()
estado = True
while True:
    valor = str(pot.read())
    print (valor)
    if valor != 'None':
        led.write(estado)
        valor = float(valor)
        estado = not estado
        arduino.pass_time(valor)
