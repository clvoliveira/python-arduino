from tkinter import *

def mudaTexto():
  label['text']='Mudou!'

janela = Tk()
janela.title("Aplicação em Tkinter")
janela.geometry("300x50")

frame = Frame(master=janela)
frame.pack()

label = Label(master=frame, text="Clique no botão e mude o texto")
label.pack()

botao = Button(master=frame, text="Mudar",command=mudaTexto)
botao.pack()

janela.mainloop()