from pyfirmata import Arduino, OUTPUT

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
led = {"verm_car": 13, "amar_car": 12, "verd_car": 11,
  "verd_ped": 10, "verm_ped": 9}

for pino in dicionario.values():
  arduino.digital[pino].mode = OUTPUT

while True:
  arduino.digital[led["verm_car"]].write(1)
  arduino.digital[led["verd_ped"]].write(1)
  arduino.pass_time(5.0)
  arduino.digital[led["verd_car"]].write(1)
  arduino.digital[led["verm_ped"]].write(1)
  arduino.digital[led["verm_car"]].write(0)
  arduino.digital[led["verd_ped"]].write(0)
  arduino.pass_time(3.0)
  arduino.digital[led["verd_car"]].write(0)
  arduino.digital[led["amar_car"]].write(1)
  arduino.pass_time(1.0)
  arduino.digital[led["amar_car"]].write(0)
