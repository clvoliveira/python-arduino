numero = {'zero': 0, 'um': 1, 'dois': 2, 'tres': 3, 'quatro': 4}
for chave in numero:
  print(chave, numero[chave])