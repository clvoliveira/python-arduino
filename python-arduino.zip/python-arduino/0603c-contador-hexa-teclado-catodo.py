from pyfirmata import Arduino

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)

hexa = [
    [ 1, 1, 1, 1, 1, 1, 0 ],
    [ 0, 1, 1, 0, 0, 0, 0 ],
    [ 1, 1, 0, 1, 1, 0, 1 ],
    [ 1, 1, 1, 1, 0, 0, 1 ],
    [ 0, 1, 1, 0, 0, 1, 1 ],
    [ 1, 0, 1, 1, 0, 1, 1 ],
    [ 1, 0, 1, 1, 1, 1, 1 ],
    [ 1, 1, 1, 0, 0, 0, 0 ],
    [ 1, 1, 1, 1, 1, 1, 1 ],
    [ 1, 1, 1, 0, 0, 1, 1 ],
    [ 1, 1, 1, 0, 1, 1, 1 ],
    [ 0, 0, 1, 1, 1, 1, 1 ],
    [ 1, 0, 0, 1, 1, 1, 0 ],
    [ 0, 1, 1, 1, 1, 0, 1 ],
    [ 1, 0, 0, 1, 1, 1, 1 ],
    [ 1, 0, 0, 0, 1, 1, 1 ]
]

binario = [
    [ 0, 0, 0, 0 ], 
    [ 0, 0, 0, 1 ], 
    [ 0, 0, 1, 0 ], 
    [ 0, 0, 1, 1 ], 
    [ 0, 1, 0, 0 ], 
    [ 0, 1, 0, 1 ], 
    [ 0, 1, 1, 0 ], 
    [ 0, 1, 1, 1 ],
    [ 1, 0, 0, 0 ], 
    [ 1, 0, 0, 1 ], 
    [ 1, 0, 1, 0 ], 
    [ 1, 0, 1, 1 ], 
    [ 1, 1, 0, 0 ], 
    [ 1, 1, 0, 1 ], 
    [ 1, 1, 1, 0 ], 
    [ 1, 1, 1, 1 ]  
]

num = 0

seg = list()
seg.append(arduino.get_pin('d:7:o'))
seg.append(arduino.get_pin('d:8:o'))
seg.append(arduino.get_pin('d:9:o'))
seg.append(arduino.get_pin('d:10:o'))
seg.append(arduino.get_pin('d:11:o'))
seg.append(arduino.get_pin('d:12:o'))
seg.append(arduino.get_pin('d:13:o'))

led = list()
led.append(arduino.get_pin('d:3:o'))
led.append(arduino.get_pin('d:4:o'))
led.append(arduino.get_pin('d:5:o'))
led.append(arduino.get_pin('d:6:o'))

def exibir_hexa(numero):
    for i in range(0, 7):
        seg[i].write(hexa[numero][i])

def exibir_binario(numero):
    for i in range(0, 4):
        led[i].write(binario[numero][i])

def limpar():
    for i in range(0, 7):
        seg[i].write(0)
    for i in range(0, 4):
        led[i].write(0)
        
while True:
    num = int(input('Digite um número entre 0 e 15: '))
    if num >= 0 and num <= 15:
        exibir_hexa(num)
        exibir_binario(num)
        arduino.pass_time(3.0)
        limpar()
    else:
        print ('Digite apenas um número entre 0 e 15! Tente de novo...')
