from pyfirmata import Arduino, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
arduino.analog[0].enable_reporting()
while True:
    valor = str(arduino.analog[0].read())
    print (valor)
    if valor != 'None':
        valor = float(valor)
        if valor < 0.5:
            arduino.digital[13].write(1)
        else:
            arduino.digital[13].write(0)
        arduino.pass_time(0.1)


