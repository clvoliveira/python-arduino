from pyfirmata import Arduino, OUTPUT

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = Arduino('COM3')
verm_car = 13
amar_car = 12
verd_car = 11
verd_ped = 10
verm_ped = 9

arduino.digital[verm_car].mode = OUTPUT
arduino.digital[amar_car].mode = OUTPUT
arduino.digital[verd_car].mode = OUTPUT
arduino.digital[verd_ped].mode = OUTPUT
arduino.digital[verm_ped].mode = OUTPUT

while True:
    arduino.digital[verm_car].write(1)
    arduino.digital[verd_ped].write(1)
    arduino.pass_time(5.0)
    arduino.digital[verd_car].write(1)
    arduino.digital[verm_ped].write(1)
    arduino.digital[verm_car].write(0)
    arduino.digital[verd_ped].write(0)
    arduino.pass_time(3.0)
    arduino.digital[verd_car].write(0)
    arduino.digital[amar_car].write(1)
    arduino.pass_time(1.0)
    arduino.digital[amar_car].write(0)

