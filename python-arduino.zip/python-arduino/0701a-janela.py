from tkinter import *

def fechar():
  janela.quit()

janela = Tk()
janela.title("Aplicação em Tkinter")
janela.geometry("300x50")

frame = Frame(master=janela)
frame.pack()

botao = Button(master = frame, text = "Fechar", command=fechar)
botao.pack()

janela.mainloop()