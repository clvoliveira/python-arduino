numero = [0, 0, 0, 0, 0]
i = 0
soma = 0.0
while i < 5:
  numero[i] = float(input("Número? "))
  soma = soma + numero[i]
  i = i + 1
media = soma / 5
print ("O valor da media é %3.1f" % media)