from pyfirmata import Arduino, OUTPUT

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = Arduino('COM3')
verm = 13
amar = 12
verd = 11

arduino.digital[verm].mode = OUTPUT
arduino.digital[amar].mode = OUTPUT
arduino.digital[verd].mode = OUTPUT

while True:
    arduino.digital[verm].write(1)
    arduino.pass_time(5.0)
    arduino.digital[verm].write(0)
    arduino.digital[verd].write(1)
    arduino.pass_time(3.0)
    arduino.digital[verd].write(0)
    arduino.digital[amar].write(1)
    arduino.pass_time(1.0)
    arduino.digital[amar].write(0)


