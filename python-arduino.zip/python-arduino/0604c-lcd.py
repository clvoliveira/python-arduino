from pyfirmata import Arduino
import lcd

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
    
lcd.escrever(arduino, 0, 0, 'Ola pessoal!')
lcd.escrever(arduino, 0, 1, 'Python+Arduino')
arduino.pass_time(5.0)
lcd.limpar(arduino)
arduino.exit()
