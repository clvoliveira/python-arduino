from pyfirmata import Arduino, INPUT, OUTPUT, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
led = 13
botao = 2
anterior = False
estado = False

it = util.Iterator(arduino)
it.start()

arduino.digital[botao].mode = INPUT
arduino.digital[botao].enable_reporting()
arduino.digital[led].mode = OUTPUT

while True:
    valor = arduino.digital[botao].read()
    if valor == True and anterior == False:
        estado = not estado
        print('LED', estado)
        arduino.digital[led].write(estado)
    anterior = valor
    arduino.pass_time(0.05)
