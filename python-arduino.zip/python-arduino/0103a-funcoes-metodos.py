num1 = int(input("Digite um valor: "))
num2 = int(input("Digite outro valor: "))
soma = num1 + num2
print ("A soma de ", num1, " com ", num2, " é ", soma)