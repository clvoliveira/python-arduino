from pyfirmata import Arduino, OUTPUT

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
led1 = 11
led2 = 12
led3 = 13
num  =  0

digito = [
    [ 0, 0, 0 ], 
    [ 0, 0, 1 ], 
    [ 0, 1, 0 ], 
    [ 0, 1, 1 ], 
    [ 1, 0, 0 ], 
    [ 1, 0, 1 ], 
    [ 1, 1, 0 ], 
    [ 1, 1, 1 ]  
]

arduino.digital[led1].mode = OUTPUT
arduino.digital[led2].mode = OUTPUT
arduino.digital[led3].mode = OUTPUT

while True:
    arduino.digital[led1].write(digito[num][0])
    arduino.digital[led2].write(digito[num][1])
    arduino.digital[led3].write(digito[num][2])
    arduino.pass_time(1.0)
    num = num + 1
    if num > 7:
        num = 0

