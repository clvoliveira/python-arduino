from pyfirmata import Arduino, PWM, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
pot = arduino.get_pin('a:0:i')
led = arduino.get_pin('d:9:p')
pot.enable_reporting()
while True:
    valor = str(pot.read())
    print (valor)
    if valor != 'None':
        valor = float(valor)
        led.write(valor)
    arduino.pass_time(0.05)
