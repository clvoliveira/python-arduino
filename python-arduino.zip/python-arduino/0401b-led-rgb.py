from pyfirmata import Arduino, PWM

import random

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
vermelho = arduino.get_pin('d:9:p')
azul = arduino.get_pin('d:6:p')
verde = arduino.get_pin('d:5:p')

while True:
    vermelho.write(random.random())
    azul.write(random.random())
    verde.write(random.random())
    arduino.pass_time(2.0)
