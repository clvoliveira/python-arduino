from pyfirmata import Arduino
import lcd

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)

nome = input('Digite o seu nome: ')    
lcd.escrever(arduino, 0, 0, 'Ola ' + nome)
arduino.pass_time(5.0)
lcd.limpar(arduino)
arduino.exit()
