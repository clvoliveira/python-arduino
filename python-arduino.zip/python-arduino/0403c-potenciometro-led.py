from pyfirmata import Arduino, PWM, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
arduino.analog[0].enable_reporting()
arduino.digital[9].mode = PWM
while True:
    valor = str(arduino.analog[0].read())
    print (valor)
    if valor != 'None':
        valor = float(valor)
        arduino.digital[9].write(valor)
    arduino.pass_time(0.05)
