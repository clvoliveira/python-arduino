from pyfirmata import Arduino, INPUT, OUTPUT, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
led   = 13
botao =  2

it = util.Iterator(arduino)
it.start()

arduino.digital[botao].mode = INPUT
arduino.digital[botao].enable_reporting()
arduino.digital[led].mode = OUTPUT

while True:
    estado = arduino.digital[botao].read()
    arduino.digital[led].write(estado)

