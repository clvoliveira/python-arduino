from pyfirmata import Arduino, util

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()

ldr = arduino.get_pin('a:0:i')
led = arduino.get_pin('d:13:o')
ldr.enable_reporting()
while True:
    valor = str(ldr.read())
    print (valor)
    if valor != 'None':
        valor = float(valor)
        if valor < 0.5:
            led.write(1)
        else:
            led.write(0)
        arduino.pass_time(0.1)
