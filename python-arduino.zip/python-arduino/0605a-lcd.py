from pyfirmata import Arduino, util, INPUT
from datetime import datetime
import lcd

mes_extenso = ['Janeiro', 'Fevereiro', 'Marco', 'Abril',
               'Maio', 'Junho', 'Julho', 'Agosto',
               'Setembro', 'Outubro', 'Novembro', 'Dezembro']
dia_semana = ['Segunda', 'Terca', 'Quarta', 'Quinta',
              'Sexta', 'Sabado', 'Domingo']
botao = 6
anterior = False
funcao  =  0
linha = ['', '']

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
arduino.digital[botao].mode = INPUT
it = util.Iterator(arduino)
it.start()

while True:
    agora = datetime.now()
    valor = arduino.digital[botao].read()
    
    if valor == True and anterior == False:
        lcd.limpar(arduino)
        funcao = funcao + 1
        if funcao > 1:
            funcao = 0

    if funcao == 0:
        linha[0] = str(agora.day) + '/' + str(agora.month) + '/' + str(agora.year)
        linha[1] = str(agora.hour) + ':' + str(agora.minute).zfill(2) + ':' + str(agora.second).zfill(2)
    else:
        linha[0] = mes_extenso[agora.month - 1] + ' ' + str(agora.day)
        linha[1] = dia_semana[agora.weekday()]
    
    for i in range(2):
        lcd.escrever(arduino, 0, i, linha[i])
        
    anterior = valor
    arduino.pass_time(0.05)
