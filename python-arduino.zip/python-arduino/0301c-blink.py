from pyfirmata import Arduino

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
led = arduino.get_pin('d:13:o')

while True:
    led.write(1)
    arduino.pass_time(0.5)
    led.write(0)
    arduino.pass_time(0.5)
