from pyfirmata import Arduino

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = Arduino('COM3')
verm = arduino.get_pin('d:13:o')
amar = arduino.get_pin('d:12:o')
verd = arduino.get_pin('d:11:o')

while True:
    verm.write(1)
    arduino.pass_time(5.0)
    verm.write(0)
    verd.write(1)
    arduino.pass_time(3.0)
    verd.write(0)
    amar.write(1)
    arduino.pass_time(1.0)
    amar.write(0)

