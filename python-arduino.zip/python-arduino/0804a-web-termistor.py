from flask import Flask, render_template
from arduino import Arduino
from math import log
import datetime

def obter_temp_celsius (valor):
  tempK = log(10000.0 * (1.0 / valor - 1))
  tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
  tempC = tempK - 273.15
  return tempC

dado = {'temperatura' : 0}

app = Flask(__name__)
@app.route('/')
def inicio():
  arduino = Arduino()
  valor = arduino.analogRead(0)
  #print (arduino, valor)
  if valor > 0.0 and valor <= 1.0:
    dado['temperatura'] = round(obter_temp_celsius(valor), 1)
  else:
    dado['temperatura'] = '...'
  return render_template('temperatura.html', **dado)
 
if __name__ == '__main__':
  app.run(debug=True)

