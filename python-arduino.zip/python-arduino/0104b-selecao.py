numero = int(input("Digite um número: "))
if numero == 1:
  print ("Um")
elif numero == 2:
  print ("Dois")
elif numero == 3:
  print ("Três")
else:
  print ("Não sei")