from pyfirmata import Arduino, OUTPUT

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
arduino.digital[13].mode = OUTPUT
while True:
  estado = input('Digite 1 para ligar o LED ou 0 para desligar: ')
  arduino.digital[13].write(int(estado))
