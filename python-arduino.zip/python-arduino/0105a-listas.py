VALORES = [56, 45, 23, 14, 61]
print (VALORES[2])