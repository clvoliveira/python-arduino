from pyfirmata import Arduino, util
from math import log

def obter_temp_kelvin (valor):
    tempK = log(10000.0 * (1.0 / valor - 1))
    tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
    return tempK

def obter_temp_celsius (valor):
    tempC = obter_temp_kelvin(valor) - 273.15
    return tempC

def obter_temp_fahrenheit (valor):
    tempF = (obter_temp_kelvin(valor) - 273.15) * 1.8 + 32.00
    return tempF

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()
botao = arduino.get_pin('d:2:i')
termistor = arduino.get_pin('a:0:i')
termistor.enable_reporting()
escala = 0
anterior = False

while True:
    estado = botao.read()
    if estado == True and anterior == False:
        escala = escala + 1
        if escala > 2:
            escala = 0
    valor = str(termistor.read())
    if valor != 'None':
        valor = float(valor)
        if escala == 0:
            print ('Temperatura:', round(obter_temp_celsius(valor), 1), '°C')
        elif escala == 1:
            print ('Temperatura:', round(obter_temp_fahrenheit(valor), 1), '°F')
        else:
            print ('Temperatura:', round(obter_temp_kelvin(valor), 1), 'K')
    anterior = estado
    arduino.pass_time(0.05)
