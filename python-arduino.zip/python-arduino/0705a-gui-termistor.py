from pyfirmata import Arduino, util
from math import log
from tkinter import *
from tkinter import ttk

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)
it = util.Iterator(arduino)
it.start()

arduino.analog[0].enable_reporting()

janela = Tk()
janela.title("Mostrando a temperatura")
janela.geometry("500x300")

frame = Frame(master=janela)
frame.pack()

estilo = ttk.Style()
estilo.theme_use('default')

temperatura = StringVar()

def obter_temp_celsius (valor):
  tempK = log(10000.0 * (1.0 / valor - 1))
  tempK = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * tempK * tempK )) * tempK)
  tempC = tempK - 273.15
  return tempC

def mostra_temp():
  valor = str(arduino.analog[0].read())
  if valor != 'None':
    valor = float(valor)
    tempC = obter_temp_celsius(valor)
    if tempC >= 30.0:
     estilo.configure(
       "color.Horizontal.TProgressbar",
       background='red')
    elif tempC > 20 and tempC < 30:
      estilo.configure(
        "color.Horizontal.TProgressbar",
        background='orange')
    else:
      estilo.configure(
        "color.Horizontal.TProgressbar",
        background='blue')
    temperatura.set(str(round(tempC,1)) + '°C')
    progressbar["value"]=tempC
    janela.after(500, mostra_temp)

progressbar = ttk.Progressbar(frame, style='color.Horizontal.TProgressbar', orient="vertical",length=220,mode="determinate")
progressbar.grid(row=0, column=0)

label=Label(frame, textvariable=temperatura, font=("Helvetica", 20))
label.grid(row=0, column=1)

janela.protocol('WM_DELETE_WINDOW', janela.destroy)
janela.after(500,mostra_temp)
janela.mainloop()
