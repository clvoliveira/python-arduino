from pyfirmata import Arduino

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
arduino = Arduino('COM3')
verm_car = arduino.get_pin('d:13:o')
amar_car = arduino.get_pin('d:12:o')
verd_car = arduino.get_pin('d:11:o')
verd_ped = arduino.get_pin('d:10:o')
verm_ped = arduino.get_pin('d:9:o')

while True:
    verm_car.write(1)
    verd_ped.write(1)
    arduino.pass_time(5.0)
    verd_car.write(1)
    verm_ped.write(1)
    verm_car.write(0)
    verd_ped.write(0)
    arduino.pass_time(3.0)
    verd_car.write(0)
    amar_car.write(1)
    arduino.pass_time(1.0)
    amar_car.write(0)
