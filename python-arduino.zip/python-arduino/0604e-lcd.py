from pyfirmata import Arduino
from datetime import datetime
import lcd

# Especifique a Porta Serial onde o Arduino
# está conectado, por exemplo, COM3
PORTA = 'COM3'

arduino = Arduino(PORTA)

while True:
    agora = datetime.now()
    data = str(agora.day) + '/' + str(agora.month) + '/' + str(agora.year)
    hora = str(agora.hour) + ':' + str(agora.minute).zfill(2) + ':' + str(agora.second).zfill(2)
    lcd.escrever(arduino, 0, 0, data)
    lcd.escrever(arduino, 0, 1, hora)
    arduino.pass_time(1.0)
